<ul>
  <li><a href="uhome.php"><b>HOME</a></b></li>
   <li><a href="search_books.php"><b>SEARCH BOOKS</a></b></li>
    <li><a href="request.php"><b>REQUEST</a></b></li>
	 		 <li><a href="uchangepass.php"><b>CHANGE PASSWORD</a></b></li>
		  <li><a href="logout.php"><b>LOGOUT</a></b></li>
		  </ul>