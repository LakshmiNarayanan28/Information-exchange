<html>
<head>
<title>IT INFORMATION EXCHANGE</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="animate.css">
</head>
<style>
p{
	font-size:16px;
}
b{
	font-size:18px;
}
ul{
	margin-left:10px;
	margin-right:0px;
	list-style-type:square;
}
	li{
		margin-bottom:5px;
	}
</style>
<body>
<div id="container">
<div id="header">
<center>
<h1>KLNCE IT DEPARTMENT-INFORMATION EXCHANGE</h1>


</center>
</div>
<div id="wrapper">
<p>     </p>

<b>VISION OF OUR DEPARTMENT:</b>
<p>
To Emerge As A Centre Of Excellence Through Innovative Technical Education And Research In Information Technology.</p>

<b>MISSION OF OUR DEPARTMENT:</b>
<p>
To Produce Competent Information Technology Professionals To Face The Industrial And Societal Challenges By Imparting 
Quality Education With Ethical Values.
</p>


<b>MAIN OBJECTIVE</b>
<ul>
<li>For Share Q&A for Your Academics</li>
<li>Share Important Updates Of Our Department/college</li>
<li>Share Events Conducted by our Department/College</li>
<li>Share Any Placement Activities conducted By Our Department/College</li>
<li>Also If You Have Any Queries Ask Me Anytime...</li>
</ul>

<center>
<img src="uq.gif" alt="smiley face" width="130" height="130">
<b><p class="animated zoomIn infinite">"Motivate Yourself Again And Again To Achieve"</p>
</center></b>



</div>
<div id="navi">
<?php 
  include "sidebar.php";
  ?>

</div>
<div id="footer">
<center>
<p>Copyright &copy;By LakshmiNarayanan</p>
</center>
</div>
</div>
</body>
</html>