<ul>
  <li><a href="ahome.php"><b>HOME</b></a></li>
   <li><a href="view_student.php"><b>VIEW STUDENT</a></b></li>
    <li><a href="upload_books.php"><b>UPLOAD BOOKS/INFO</a></b></li>
	 <li><a href="view_books.php"><b>VIEW BOOKS</a></b></li>
	   <li><a href="view_req.php"><b>VIEW REQUEST</a></b></li>
	    <li><a href="view_comm.php"><b>VIEW COMMENTS</a></b></li>
		 <li><a href="achangepass.php"><b>CHANGE PASSWORD</a></b></li>
		  <li><a href="logout.php"><b>LOGOUT</a></b></li>
		  </ul>