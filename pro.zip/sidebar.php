<ul>
   <li><a href="alogin.php"><b>Admin Login</a></b></link>
    <li><a href="ulogin.php"><b>User Login</a></b></link>
	 <li><a href="new.php"><b>New User</a></b></link>
	 
		</ul>